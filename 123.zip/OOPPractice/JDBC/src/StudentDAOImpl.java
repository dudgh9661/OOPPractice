import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;

public class StudentDAOImpl implements StudentDAO{
	
	private Connection conn;
	
	public StudentDAOImpl () throws ClassNotFoundException, SQLException {
		//�����ڴ� ��� �޼����� ������ ����, �������� ó���� �κ��� ó�����ִ� ������ �Ѵ�.
		//1. ����̹� �ε�
		String driver = "oracle.jdbc.driver.OracleDriver";
		Class.forName(driver);
		System.out.println("1. driver loading OK");

		//2. DBMS connection
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		conn = DriverManager.getConnection(url, "hr", "hr");
		System.out.println("2. DBMS connection OK");
	}
	@Override
	public String login(String studentId, String pw) {
		String sql = "select name from students where student_id=? and pw=?";
		String name = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, studentId);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			if( rs.next() )
				name = rs.getString(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return name;
	}

	@Override
	public boolean setPw(String studentId, String oldPw, String newPw) {
		// TODO Auto-generated method stub
		String sql = "update students set pw = ? where student_id = ? and pw = ?";
		boolean flag = false;

		return false;
	}

	@Override
	public StudentVO getStudent(String studentId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<StudentVO> getStudents() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<StudentVO> getStudents(String name) {
		// TODO Auto-generated method stub
		String sql = "select student_id from students where name = ?";
		Collection<StudentVO> list = new ArrayList();
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				list.add(new StudentVO(rs.getString(1), name));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return list;
	}

}
