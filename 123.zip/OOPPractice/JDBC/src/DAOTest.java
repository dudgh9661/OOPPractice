import java.sql.SQLException;

public class DAOTest {
	public static void main(String[] args) {
		try {
			StudentDAO dao = new StudentDAOImpl();
			//Login Test
			//System.out.println(dao.login("jjeon", "1111"));
			//System.out.println(dao.login("jjeon", "0000"));
			//System.out.println(dao.login("' || 1=1 --", "1111"));
			
			//�̸� �˻�
			System.out.println(dao.getStudents("ȫ�浿"));
			System.out.println(dao.getStudents("����"));
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} //main
}
