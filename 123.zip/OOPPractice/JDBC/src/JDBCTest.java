import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

//���� üũ�� ���� throws�ϴ� ���� �����Ѵ�. ��, ������ �������� Ȯ��!
public class JDBCTest {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//jdbc:oracle:thin:@localhost:1521:XE
		//1. ����̹� �ε�
		String driver = "oracle.jdbc.driver.OracleDriver";
		Class.forName(driver);
		System.out.println("1. driver loading OK");
		
		//2. DBMS connection
		String url = "jdbc:oracle:thin:@localhost:1521:XE";
		Connection conn = DriverManager.getConnection(url, "hr", "hr");
		System.out.println("2. DBMS connection OK");
		
		//3.4
		String sql = "select employee_id, email, salary from employees";
		Statement stmt = conn.createStatement();
		ResultSet rs = stmt.executeQuery(sql);
		
		while(rs.next()) {
			System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getFloat(3));
		}
		
		//5. disable connection
		rs.close();
		stmt.close();
		conn.close();
	} //main
}
