package com.oopsw.simple;

public class UserObject {
	public static void main(String [] args) {
		System.out.println("Java...");
	}
}
