public class TypeTest_01 {
	public static void main(String[] args) {
		int num1 = 10;
		double num2 = 10.0;
		//
	} //main end
} //class end
