import java.util.Scanner;

public class Gugudan {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		StringBuffer s = new StringBuffer();
		
		int number = sc.nextInt();
		
		for(int i = 1; i <= 9; i++) {
			for(int j = number; j <= 9; j++) {
				s.append(j + "*" + i + " = " + j*i + "\t");
			}
			s.append("\n");
		}
		System.out.println(s);
		
	}

}
