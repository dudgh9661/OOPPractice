
public class TypeTest_02 {
	public static void main(String[] args) {
		
	}
}
