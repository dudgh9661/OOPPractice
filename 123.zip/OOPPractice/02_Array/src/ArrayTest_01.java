import java.util.Scanner;

public class ArrayTest_01 {

	public static void main(String[] args) {
		String[] str = new String[2];
		Scanner sc = new Scanner(System.in);

		for(int i = 0; i < 2; i++) {
				String input = sc.nextLine();
				str[i] = input;
		}
		
		for(String tmp : str) {
			System.out.println(tmp);
		}
	}
}


