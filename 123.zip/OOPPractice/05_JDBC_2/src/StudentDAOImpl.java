import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

public class StudentDAOImpl implements StudentDAO{
	private Connection conn;
	public StudentDAOImpl() throws ClassNotFoundException, SQLException {
		// ��� �޼����� ������ ���� ���� ó��
		//1.����̹� �ε�
		String driver="oracle.jdbc.driver.OracleDriver";
		Class.forName(driver);
		System.out.println("1. ����̹� �ε� OK");
		//2.DBMS ���� 
		String url="jdbc:oracle:thin:@127.0.0.1:1521:XE";
		conn=DriverManager.getConnection(url, "hr", "hr");
		System.out.println("2 DBMS conn OK");
	}

	@Override
	public String login(String studentId, String pw) {
		String sql="select name from students "
				+ "where student_id=? and pw=?";
		String name=null;
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, studentId); //'jjeon'
			pstmt.setString(2,  pw);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next())
				name=rs.getString(1);

		} catch (SQLException e) {		e.printStackTrace();
		}		
		return name;
	}

	@Override
	public boolean setPw(String studentId, String oldPw, String newPw) {
		String sql = "update students set pw=? "
				+ "where student_id=? and pw=?";
		boolean flag = false;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, newPw);
			pstmt.setString(2, studentId);
			pstmt.setString(3, oldPw);
			flag= (pstmt.executeUpdate() == 1);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	@Override
	public StudentVO getStudent(String studentId) {
		String sql = "select  name from students where student_id=?";
		StudentVO student = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, studentId);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				student=new StudentVO(studentId, rs.getString(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return student;
	}

	@Override
	public Collection<StudentVO> getStudents() {
		String sql = "select student_id, name from students"; // ������ ?�� ����. ?�� mybatis�Է°����� ��������.
		Collection<StudentVO> list = new ArrayList<StudentVO>();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while (rs.next()) {
				list.add(new StudentVO(rs.getString(1), rs.getString(2))); // �̹� �������� �ִ°� �˸� �Ű����������ͼ� �簡��.
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

	@Override
	public Collection<StudentVO> getStudents(String name) {
		String sql="select student_id from students where name=?";
		Collection<StudentVO> list=new ArrayList();
		try {
			PreparedStatement pstmt=conn.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				list.add(new StudentVO(rs.getString(1), name));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return list;
	}

}
