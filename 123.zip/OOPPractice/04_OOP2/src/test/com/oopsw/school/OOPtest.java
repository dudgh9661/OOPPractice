package test.com.oopsw.school;

import com.oopsw.school.Student;

public class OOPtest {

	public static void main(String[] args) {
		String st1 = "hi";
		String st2 = new String("hi");
		//Student s1 = new Student("111111", "2001");
		//System.out.println(s1);
	}

}
