package test.com.oopsw.school;

import com.oopsw.school.Person;
import com.oopsw.school.Student;

public class ArrayTest {
	public static void main(String[] args) {
		
		Person[] list = new Person[2];
		list[0] = new Person("ȫ�浿", "�濵");
		list[1] = new Student("ȫ�浿", "����", "123");
		
		for(Person p : list) {
			System.out.println(p);
			if(p.getName().equals("ȫ�浿")) {
				if( p instanceof Student ) {
					System.out.println( p + "�л��Դϴ�.");
				}				
			}
		}
	}
}
