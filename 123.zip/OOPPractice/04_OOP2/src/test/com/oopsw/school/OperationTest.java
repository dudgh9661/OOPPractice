package test.com.oopsw.school;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;

import com.oopsw.school.Person;

public class OperationTest {
	
	public void printMessage(Collection c) {
		System.out.println(c.add("1234"));
		System.out.println(c.add(1234)); //int -> Integet�� �ڵ� ��ȯ.
		System.out.println(c.add(new Person("ȫ�浿", "123")));
		
		System.out.println(c.add("1234"));
		System.out.println(c.add(1234)); //int -> Integet�� �ڵ� ��ȯ.
		System.out.println(c.add(new Person("ȫ�浿", "123")));
		
		System.out.println(c);
	}
	public static void main(String[] args) {
		OperationTest o = new OperationTest();
		o.printMessage(new HashSet());
		o.printMessage(new ArrayList());
	}
}
