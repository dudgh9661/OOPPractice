package com.oopsw.school;

public class Employee extends Person {
	public Employee() {}
	
	public Employee(String name, String department) {
		super(name, department);
	}

	
	@Override
	public void print() {
		System.out.println("--����--");
		System.out.println("�̸� : " + getName() + ", �μ� : " + getDepartment() + "\n"); 
	}
}
