package com.oopsw.school;

public class Manager extends Person {
	private String position;
	
	public Manager() {}
	
	public Manager(String name, String department, String position) {
		super(name, department);
		this.position = position;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}
	
	@Override
	public void print() {
		System.out.println("--������--");
		System.out.println("�̸� : " + getName() + ", �μ� : " + getDepartment() + 
				" ��å : " + position + "\n");
	}
	
}
