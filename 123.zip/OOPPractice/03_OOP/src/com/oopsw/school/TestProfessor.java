package com.oopsw.school;

public class TestProfessor {
	public static void main(String[] args) {
		Professor p = new Professor(123, "ȫ���");
		p.print();
	}
}
