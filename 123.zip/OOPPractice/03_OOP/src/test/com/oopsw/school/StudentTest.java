package test.com.oopsw.school;

import com.oopsw.school.Student;

public class StudentTest {
	public static void main(String[] args) {
		Student s = new Student("201","�迵ȣ");
		s.print();
	}
}
